
package dbtoko_raffa;

import java.sql.*;

public class Config {
    public static Connection configDB() throws SQLException {
        try {
            String url = "jdbc:mysql://localhost:3306/dbtoko_raffa"; // URL DB Anda
            String user = "root"; // Username MySQL Anda
            String pass = ""; // Password MySQL Anda
            DriverManager.registerDriver(new com.mysql.jdbc.Driver());
            return DriverManager.getConnection(url, user, pass);
        } catch (SQLException e) {
            System.out.println("Koneksi ke database gagal: " + e.getMessage());
            throw e;
        }
    }
}


