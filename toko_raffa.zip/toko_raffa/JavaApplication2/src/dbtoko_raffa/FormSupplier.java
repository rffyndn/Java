/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package dbtoko_raffa;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class FormSupplier extends javax.swing.JFrame {

    Connection connection;
    Statement statement;
    
    public FormSupplier() {
        initComponents();
        setTitle("Form Data Supplier");
        setLocationRelativeTo(null);
        try{
            connection = Config.configDB();
            statement = connection.createStatement();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
        loadData();
        kosong();
    }
    
    
    private void loadData() {
        DefaultTableModel tableModel = new DefaultTableModel();
        tableModel.addColumn("KODE SUPPLIER");
        tableModel.addColumn("NAMA SUPPLIER");
        tableModel.addColumn("ALAMAT");
        tableModel.addColumn("KOTA");
        tableModel.addColumn("NEGARA"); 
        tableModel.addColumn("TELEPON");
        tableModel.addColumn("EMAIL"); 
        tableModel.addColumn("NO REKENING"); 
        tableModel.addColumn("NPWP"); 
        tableModel.addColumn("PROVINSI"); 
        tableModel.addColumn("KODE POS"); 
        tableModel.addColumn("FAX"); 
        
        try {
        String sql = "SELECT * FROM tbl_supplier";
        try (ResultSet results = statement.executeQuery(sql)) {
            while (results.next()) {
                tableModel.addRow(new Object[]{
                    results.getString("kode_supplier"),
                    results.getString("nama_suplier"),
                    results.getString("alamat"),
                    results.getString("kota"),
                    results.getString("negara"),
                    results.getString("telepon"),
                    results.getString("email"),
                    results.getString("norek"),
                    results.getString("npwp"),
                    results.getString("provinsi"),
                    results.getString("kodepos"),
                    results.getString("fax")
                });
            }
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
        
        TabelSupplier.setModel(tableModel);
    }
    
    
    
     private void kosong() {
            txtkodesupplier.setText(null);
            txtnamasupplier.setText(null);
            txtalamat.setText(null);
            txtkota.setText(null);
            txtnegara.setText(null);
            txttelepon.setText(null);
            txtemail.setText(null);
            txtnorek.setText(null);
            txtnpwp.setText(null);
            txtprovinsi.setText(null);
            txtkodepos.setText(null);
            txtfax.setText(null);
        }
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        txtkodesupplier = new javax.swing.JTextField();
        txtnamasupplier = new javax.swing.JTextField();
        txtkota = new javax.swing.JTextField();
        txtnegara = new javax.swing.JTextField();
        txttelepon = new javax.swing.JTextField();
        txtemail = new javax.swing.JTextField();
        txtnorek = new javax.swing.JTextField();
        txtprovinsi = new javax.swing.JTextField();
        txtkodepos = new javax.swing.JTextField();
        txtfax = new javax.swing.JTextField();
        ButtonAdd = new javax.swing.JButton();
        buttonUpdate = new javax.swing.JButton();
        buttonDelete = new javax.swing.JButton();
        buttonClose = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        TabelSupplier = new javax.swing.JTable();
        txtcari = new javax.swing.JTextField();
        buttonCari = new javax.swing.JButton();
        jLabel14 = new javax.swing.JLabel();
        txtnpwp = new javax.swing.JTextField();
        jScrollPane3 = new javax.swing.JScrollPane();
        txtalamat = new javax.swing.JTextArea();
        buttonBack = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setText("FORM SUPPLIER");

        jLabel2.setText("Kode Supplier");

        jLabel3.setText("Nama Supplier");

        jLabel4.setText("Alamat");

        jLabel5.setText("Kota");

        jLabel6.setText("Negara");

        jLabel7.setText("Telepon");

        jLabel8.setText("Email");

        jLabel9.setText("No.Rekening");

        jLabel11.setText("Provinsi");

        jLabel12.setText("Kode Pos");

        jLabel13.setText("Fax");

        txtkodesupplier.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtkodesupplierActionPerformed(evt);
            }
        });

        txtnamasupplier.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtnamasupplierActionPerformed(evt);
            }
        });

        txtkota.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtkotaActionPerformed(evt);
            }
        });

        txtnegara.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtnegaraActionPerformed(evt);
            }
        });

        txttelepon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtteleponActionPerformed(evt);
            }
        });

        txtemail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtemailActionPerformed(evt);
            }
        });

        txtnorek.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtnorekActionPerformed(evt);
            }
        });

        txtprovinsi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtprovinsiActionPerformed(evt);
            }
        });

        txtkodepos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtkodeposActionPerformed(evt);
            }
        });

        ButtonAdd.setText("ADD DATA");
        ButtonAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButtonAddActionPerformed(evt);
            }
        });

        buttonUpdate.setText("UPDATE");
        buttonUpdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonUpdateActionPerformed(evt);
            }
        });

        buttonDelete.setText("DELETE");
        buttonDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonDeleteActionPerformed(evt);
            }
        });

        buttonClose.setText("CLOSE");
        buttonClose.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonCloseActionPerformed(evt);
            }
        });

        TabelSupplier.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "kode", "nama supplier", "alamat", "kota", "negara", "telepon", "email", "norek", "npwp", "provinsi", "kode pos", "fax"
            }
        ));
        TabelSupplier.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TabelSupplierMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(TabelSupplier);

        buttonCari.setText("CARI");
        buttonCari.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonCariActionPerformed(evt);
            }
        });

        jLabel14.setText("NPWP");

        txtnpwp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtnpwpActionPerformed(evt);
            }
        });

        txtalamat.setColumns(20);
        txtalamat.setRows(5);
        jScrollPane3.setViewportView(txtalamat);

        buttonBack.setText("BACK");
        buttonBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonBackActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(layout.createSequentialGroup()
                            .addGap(397, 397, 397)
                            .addComponent(jLabel1))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(24, 24, 24)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createSequentialGroup()
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel2)
                                        .addComponent(jLabel3)
                                        .addComponent(jLabel4)
                                        .addComponent(jLabel5)
                                        .addComponent(jLabel6)
                                        .addComponent(jLabel7))
                                    .addGap(43, 43, 43)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 256, Short.MAX_VALUE)
                                        .addComponent(txtkodesupplier)
                                        .addComponent(txtnamasupplier)
                                        .addComponent(txtkota)
                                        .addComponent(txtnegara)
                                        .addComponent(txttelepon))
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(jLabel12)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(txtkodepos, javax.swing.GroupLayout.PREFERRED_SIZE, 276, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(layout.createSequentialGroup()
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(jLabel8)
                                                    .addComponent(jLabel14)
                                                    .addComponent(jLabel9)
                                                    .addComponent(jLabel11)
                                                    .addComponent(jLabel13))
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addGroup(layout.createSequentialGroup()
                                                        .addGap(36, 36, 36)
                                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                            .addComponent(txtemail)
                                                            .addComponent(txtnorek)
                                                            .addComponent(txtprovinsi)
                                                            .addComponent(txtnpwp, javax.swing.GroupLayout.DEFAULT_SIZE, 276, Short.MAX_VALUE)))
                                                    .addGroup(layout.createSequentialGroup()
                                                        .addGap(37, 37, 37)
                                                        .addComponent(txtfax, javax.swing.GroupLayout.PREFERRED_SIZE, 276, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(ButtonAdd)
                                            .addGap(18, 18, 18)
                                            .addComponent(buttonUpdate)
                                            .addGap(18, 18, 18)
                                            .addComponent(buttonDelete)
                                            .addGap(18, 18, 18)
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(buttonBack)
                                                .addComponent(buttonClose)))))
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 864, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(0, 0, Short.MAX_VALUE)))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(285, 285, 285)
                        .addComponent(txtcari, javax.swing.GroupLayout.PREFERRED_SIZE, 209, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(buttonCari)))
                .addContainerGap(45, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jLabel1)
                .addGap(19, 19, 19)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtkodesupplier, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtemail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtnamasupplier, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtnorek, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtnpwp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel14))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtprovinsi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel11))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtkodepos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel12)))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(17, 17, 17)
                                .addComponent(jLabel4))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 8, Short.MAX_VALUE)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 7, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5)
                            .addComponent(txtkota, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(txtnegara, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txttelepon, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(ButtonAdd)
                            .addComponent(buttonUpdate)
                            .addComponent(buttonDelete)
                            .addComponent(buttonClose)
                            .addComponent(jLabel7)))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtfax, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel13))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addGap(32, 32, 32)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtcari, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(buttonCari)
                    .addComponent(buttonBack))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(72, 72, 72))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtkodesupplierActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtkodesupplierActionPerformed
        txtnamasupplier.requestFocus();
    }//GEN-LAST:event_txtkodesupplierActionPerformed

    private void txtnamasupplierActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtnamasupplierActionPerformed
        txtalamat.requestFocus();
    }//GEN-LAST:event_txtnamasupplierActionPerformed

    private void txtprovinsiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtprovinsiActionPerformed
        txtkodepos.requestFocus();
    }//GEN-LAST:event_txtprovinsiActionPerformed

    private void txtkotaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtkotaActionPerformed
        txtnegara.requestFocus();
    }//GEN-LAST:event_txtkotaActionPerformed

    private void txtnegaraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtnegaraActionPerformed
        txttelepon.requestFocus();
    }//GEN-LAST:event_txtnegaraActionPerformed

    private void txtteleponActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtteleponActionPerformed
        txtemail.requestFocus();
    }//GEN-LAST:event_txtteleponActionPerformed

    private void txtemailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtemailActionPerformed
        txtnorek.requestFocus();
    }//GEN-LAST:event_txtemailActionPerformed

    private void txtnorekActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtnorekActionPerformed
        txtnpwp.requestFocus();
    }//GEN-LAST:event_txtnorekActionPerformed

    private void txtkodeposActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtkodeposActionPerformed
        txtfax.requestFocus();
    }//GEN-LAST:event_txtkodeposActionPerformed

    private void TabelSupplierMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TabelSupplierMouseClicked
        int row= TabelSupplier.rowAtPoint(evt.getPoint());
        txtkodesupplier.setText (TabelSupplier.getValueAt (row, 0).toString());
        txtnamasupplier.setText (TabelSupplier.getValueAt (row, 1).toString());
        txtalamat.setText (TabelSupplier.getValueAt(row, 2).toString());
        txtkota.setText(TabelSupplier.getValueAt(row, 3).toString());
        txtnegara.setText (TabelSupplier.getValueAt(row, 4).toString());
        txttelepon.setText(TabelSupplier.getValueAt(row, 5).toString());
        txtemail.setText(TabelSupplier.getValueAt(row, 6).toString());
        txtnorek.setText(TabelSupplier.getValueAt(row, 7).toString());
        txtnpwp.setText(TabelSupplier.getValueAt(row, 8).toString());
        txtprovinsi.setText(TabelSupplier.getValueAt(row, 9).toString());
        txtkodepos.setText(TabelSupplier.getValueAt(row, 10).toString());
        txtfax.setText(TabelSupplier.getValueAt(row, 11).toString());
    }//GEN-LAST:event_TabelSupplierMouseClicked

    private void txtnpwpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtnpwpActionPerformed
        txtprovinsi.requestFocus();
    }//GEN-LAST:event_txtnpwpActionPerformed

    private void ButtonAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButtonAddActionPerformed
        try {
            String sql = "INSERT INTO tbl_supplier  (kode_supplier, nama_suplier, alamat, kota, negara, telepon, email, norek, npwp, provinsi, kodepos, fax)" 
                    + "VALUES ('" + txtkodesupplier.getText() + "', '" + txtnamasupplier.getText() + "' ,  '" 
                    + txtalamat.getText() + "' , '" + txtkota.getText() + "' , '" + txtnegara.getText() + "' , "
                    + "'" + txttelepon.getText() + "' , '" + txtemail.getText() + "' , '" + txtnorek.getText() + "' , "
                    + "'" + txtnpwp.getText() + "' , '" + txtprovinsi.getText() + "' , '" + txtkodepos.getText() + "' , "
                    + "'" + txtfax.getText() + "');";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.execute();
            JOptionPane.showMessageDialog(null, "Data Berhasil Ditambahkan");
            
            loadData();
            kosong();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
    }//GEN-LAST:event_ButtonAddActionPerformed

    private void buttonUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonUpdateActionPerformed
        try {
            int telepon = Integer.parseInt(txttelepon.getText());
            int norek = Integer.parseInt(txtnorek.getText());
            int kodepos = Integer.parseInt(txtkodepos.getText());
    
            String sql = "UPDATE tbl_supplier SET nama_suplier = txtnamasupplier, alamat = txtalamat, kota = txtkota, negara = ?, telepon = ?, email = ?, "
                         + "norek = ?, npwp = ?, provinsi = ?, kodepos = ?, fax = ? WHERE kode_supplier = ?";

            PreparedStatement preparedStatement = connection.prepareStatement(sql);
    
            // Setting parameters for the prepared statement
            preparedStatement.setString(1, txtnamasupplier.getText());
            preparedStatement.setString(2, txtalamat.getText());
            preparedStatement.setString(3, txtkota.getText());
            preparedStatement.setString(4, txtnegara.getText());
            preparedStatement.setInt(5, telepon);
            preparedStatement.setString(6, txtemail.getText());
            preparedStatement.setString(7, txtnorek.getText()); // Change to setString since norek is usually a string (account number)
            preparedStatement.setString(8, txtnpwp.getText());
            preparedStatement.setString(9, txtprovinsi.getText());
            preparedStatement.setInt(10, kodepos);
            preparedStatement.setString(11, txtfax.getText());
            preparedStatement.setString(12, txtkodesupplier.getText());

            // Executing the update
            preparedStatement.executeUpdate();
    
            JOptionPane.showMessageDialog(null, "Data Berhasil Diubah");
    
            loadData();
            kosong();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Error: Format nomor tidak valid - " + e.getMessage());
            }

    }//GEN-LAST:event_buttonUpdateActionPerformed

    private void buttonDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonDeleteActionPerformed
        try {
            String sql = "DELETE FROM tbl_supplier WHERE kode_supplier= '" + txtkodesupplier.getText() + "';";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.execute();
            JOptionPane.showMessageDialog(null, "Data Berhasil Dihapus!");
            
            loadData();
            kosong();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
    }//GEN-LAST:event_buttonDeleteActionPerformed

    private void buttonCloseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonCloseActionPerformed
        FormHome.main(null);
        dispose();
    }//GEN-LAST:event_buttonCloseActionPerformed

    private void buttonCariActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonCariActionPerformed
        try {          
    String sql = "SELECT * FROM tbl_supplier WHERE kode_supplier LIKE '%" + txtcari.getText() + "%' " +
                 "OR nama_suplier LIKE '%" + txtcari.getText() + "%'";
    java.sql.Connection Connection = (java.sql.Connection) Config.configDB();
    java.sql.Statement stm = connection.createStatement();
    java.sql.ResultSet resultset = stm.executeQuery(sql);            
    
    // Buat model tabel baru
    DefaultTableModel model = new DefaultTableModel();
    
    // Tambahkan kolom ke dalam model
    model.addColumn("kode_supplier");
    model.addColumn("nama_suplier");
    model.addColumn("alamat");
    model.addColumn("kota");
    model.addColumn("negara"); 
    model.addColumn("telepon");
    model.addColumn("email"); 
    model.addColumn("norek"); 
    model.addColumn("npwp"); 
    model.addColumn("provinsi"); 
    model.addColumn("kodepos"); 
    model.addColumn("fax"); 
    
    // Isi data ke dalam tabel
    while(resultset.next()) {
        model.addRow(new Object[]{
            resultset.getString("kode_supplier"), 
            resultset.getString("nama_suplier"),
            resultset.getString("alamat"), 
            resultset.getString("kota"), 
            resultset.getString("negara"),
            resultset.getString("telepon"),
            resultset.getString("email"),
            resultset.getString("norek"),
            resultset.getString("npwp"),
            resultset.getString("provinsi"),
            resultset.getString("kodepos"),
            resultset.getString("fax")
        });
    }

    // Set model ke tabel
    TabelSupplier.setModel(model);
    
} catch (SQLException e) {        
}

    }//GEN-LAST:event_buttonCariActionPerformed

    private void buttonBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonBackActionPerformed
        FormDashboardAdmin.main(null);
        dispose();
    }//GEN-LAST:event_buttonBackActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FormSupplier.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new FormSupplier().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ButtonAdd;
    private javax.swing.JTable TabelSupplier;
    private javax.swing.JButton buttonBack;
    private javax.swing.JButton buttonCari;
    private javax.swing.JButton buttonClose;
    private javax.swing.JButton buttonDelete;
    private javax.swing.JButton buttonUpdate;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTextArea txtalamat;
    private javax.swing.JTextField txtcari;
    private javax.swing.JTextField txtemail;
    private javax.swing.JTextField txtfax;
    private javax.swing.JTextField txtkodepos;
    private javax.swing.JTextField txtkodesupplier;
    private javax.swing.JTextField txtkota;
    private javax.swing.JTextField txtnamasupplier;
    private javax.swing.JTextField txtnegara;
    private javax.swing.JTextField txtnorek;
    private javax.swing.JTextField txtnpwp;
    private javax.swing.JTextField txtprovinsi;
    private javax.swing.JTextField txttelepon;
    // End of variables declaration//GEN-END:variables


}
 
